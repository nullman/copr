#ifndef EMULATOR_API_H
#define EMULATOR_API_H

#include <stdbool.h>

#include "options.h"

extern void press_key( int hpkey );
extern void release_key( int hpkey );
extern bool is_key_pressed( int hpkey );

extern unsigned char get_annunciators( void );
extern bool get_display_state( void );
extern void get_lcd_buffer( int* target );
extern int get_contrast( void );

extern void init_emulator( void );
extern void exit_emulator( void );

#endif /* EMULATOR_API_H */

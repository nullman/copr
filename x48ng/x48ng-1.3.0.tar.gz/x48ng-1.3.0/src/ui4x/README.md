# ui4x

Standalone HP 48s(x)/48g(x)/40g/49g(+)/50g emulator front-end ready to be plugged into emulators.

Provide both GUIs implemented in Gtk4 and SDL (2 or 3) and TUI in ncurses.

Originally extracted from x48ng and x50ng.

## How to use?

To plug an emulator you'll want to look into the interface defined in src/api.h
A dummy use is available in example/

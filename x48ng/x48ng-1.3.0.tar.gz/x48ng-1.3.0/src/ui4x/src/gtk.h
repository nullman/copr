#ifndef _UI4x_GTK_H
#  define _UI4x_GTK_H 1

extern void gtk_ui_refresh_lcd( void );
extern void gtk_ui4x_handle_pending_inputs( void );
extern void gtk_ui4x_init( void );
extern void gtk_exit( void );

#endif /* _UI4x_GTK_H */

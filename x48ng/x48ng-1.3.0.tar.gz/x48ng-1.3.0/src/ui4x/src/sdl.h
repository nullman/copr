#ifndef _UI4x_SDL_H
#  define _UI4x_SDL_H 1

extern void sdl_ui_refresh_lcd( void );
extern void sdl_ui4x_handle_pending_inputs( void );
extern void sdl_ui4x_init( void );
extern void sdl_exit( void );

#endif /* _UI4x_SDL_H */
